let userName = prompt("your name?")
let lastName = prompt("your lastname?")
let age = prompt("your age?")

document.write("<div class='bg'>"
   + "<div>" + userName + "</div>"
   + "<div>" + lastName + "</div>"
   + "<div>" + age + "</div>"
   + "</div>")
